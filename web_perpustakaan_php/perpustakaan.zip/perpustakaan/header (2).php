<?php $base = "/web_perpustakaan_php/perpustakaan"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="<?= $base ?>/index.php">Perpustakaan</a>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item"><a href="<?= $base ?>/index.php" class="nav-link">Dashboard</a></li>
      <li class="nav-item"><a href="<?= $base ?>/pages/buku.php" class="nav-link">Buku</a></li>
      <li class="nav-item"><a href="<?= $base ?>/pages/anggota.php" class="nav-link">Anggota</a></li>
      <li class="nav-item"><a href="<?= $base ?>/pages/peminjaman.php" class="nav-link">Peminjaman</a></li>
      <li class="nav-item"><a href="<?= $base ?>/logout.php" class="nav-link">Logout</a></li>
    </ul>
  </div>
</nav>